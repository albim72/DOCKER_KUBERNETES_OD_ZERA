import tensorflow as tf
import numpy as np
from data_loader import load_data

def predict():
    (_, _), (x_test, y_test) = load_data()
    model = tf.keras.models.load_model("model.h5")
    
    predictions = model.predict(x_test[:5])
    print("Predicted labels:", np.argmax(predictions, axis=1))
    print("Actual labels:", y_test[:5])

if __name__ == "__main__":
    predict()
