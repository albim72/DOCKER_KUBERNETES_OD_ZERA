import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf

# Wczytanie danych i modelu
model = tf.keras.models.load_model("model.h5")
data = np.load("data.npz")
x_test, y_test = data["x_test"], data["y_test"]

# Predykcja
predictions = model.predict(x_test)
predicted_labels = np.argmax(predictions, axis=1)

# Rysowanie pierwszych 5 obrazków z etykietami
fig, axes = plt.subplots(1, 5, figsize=(15,3))
for i, ax in enumerate(axes):
    ax.imshow(x_test[i])
    ax.set_title(f"P: {predicted_labels[i]}, T: {y_test[i][0]}")
    ax.axis("off")

plt.show()
