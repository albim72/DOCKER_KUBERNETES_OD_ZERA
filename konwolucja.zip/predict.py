import tensorflow as tf
import numpy as np

# Wczytanie modelu i danych
model = tf.keras.models.load_model("model.h5")
data = np.load("data.npz")
x_test, y_test = data["x_test"], data["y_test"]

# Predykcja
predictions = model.predict(x_test[:5])
predicted_labels = np.argmax(predictions, axis=1)

print(f"Prawdziwe etykiety: {y_test[:5].flatten()}")
print(f"Przewidziane etykiety: {predicted_labels}")
